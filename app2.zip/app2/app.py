def add(a,b):
	"""
	a,b: int: summation
	a,b: str, list: concatenation
	a int, b str: None
	"""
	try:
		return a+b
	except:
		return None