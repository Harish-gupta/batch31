host="10.10.82.3"
username="user1"
password=2345
port=3578