import config
import config1
print config.host
print config.username
print config.password
print config.port


print config1.host
print config1.username
print config1.password
print config1.port