host="10.10.82.4"
username="user2"
password=2346
port=3579