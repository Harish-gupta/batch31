print "if1"
def fun():
	return "this is funin if1"