print "hr"
def fun():
	return "fun in hr"