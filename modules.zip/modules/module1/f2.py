print "f2"
def fun():
	return "this is funin f2"