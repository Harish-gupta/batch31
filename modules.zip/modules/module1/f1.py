print "f1"
def fun():
	return "this is funin f1"