import inner
print inner.if1.fun()