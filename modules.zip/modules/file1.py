def fun():
	print "this is fun in file1"

if __name__ == "__main__":
	fun()