import logging
def create_customer(c_id,c_name):
	logging.debug("customer id: %s, customer name: %s"%(c_id, c_name))
	####
	logging.info("customer created successfully!")
if __name__ == "__main__":
	pass
